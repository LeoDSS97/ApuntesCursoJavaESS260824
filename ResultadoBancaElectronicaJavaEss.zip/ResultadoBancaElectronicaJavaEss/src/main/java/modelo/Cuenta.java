package modelo;

import java.time.LocalDate;
import java.time.Period;

public abstract class Cuenta {
    protected int numeroCuenta;
    protected char tipoCuenta;
    protected double saldo;
    protected LocalDate fechaAlta;

    protected Cuenta(int numeroCuenta, char tipoCuenta, double saldo) {
        this.numeroCuenta = numeroCuenta;
        this.tipoCuenta = tipoCuenta;
        this.saldo = saldo;
        this.fechaAlta = LocalDate.now();
    }

    public void deposito(double cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad del deposito debe ser positiva");
        }
        saldo += cantidad;
        reportarOperacion("abono", cantidad);
    }

    public double retiro(double cantidad) {
        validarCantidad(cantidad);
        if (cantidad > saldo) {
            throw new SaldoInsuficienteException("Saldo insuficiente");
        }
        saldo -= cantidad;
        reportarOperacion("retiro", cantidad);
        return cantidad;
    }

    protected void validarCantidad(double cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser positiva");
        }
    }

    protected void reportarOperacion(String operacion, double cantidad) {
        System.out.printf("Cuenta: %d, Operacion: %s %.2f pesos, saldo %.2f%n",
                numeroCuenta, operacion, cantidad, saldo);
    }

    public void imprimirCuenta() {
        System.out.printf("Cuenta: %d, Tipo: %c, Saldo: %.2f, Fecha de alta: %s%n",
                numeroCuenta, tipoCuenta, saldo, fechaAlta);
    }

    public long calculaVigencia() {
        long meses = Period.between(fechaAlta, LocalDate.now()).toTotalMonths();
        System.out.printf("La cuenta %d tiene %d meses de vigencia.%n", numeroCuenta, meses);
        return meses;
    }

    public int getNumeroCuenta() { return numeroCuenta; }
    public void setNumeroCuenta(int numeroCuenta) { this.numeroCuenta = numeroCuenta; }
    public char getTipoCuenta() { return tipoCuenta; }
    public void setTipoCuenta(char tipoCuenta) { this.tipoCuenta = tipoCuenta; }
    public double getSaldo() { return saldo; }
    public void setSaldo(double saldo) { this.saldo = saldo; }
    public LocalDate getFechaAlta() { return fechaAlta; }
    public void setFechaAlta(LocalDate fechaAlta) { this.fechaAlta = fechaAlta; }

    public abstract String descripcionDeLaCuenta();
}