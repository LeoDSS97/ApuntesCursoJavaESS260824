package modelo;

import java.time.LocalDate;

public class PruebaCuenta {
    public static void main(String[] args) {
        CuentaAhorros cuenta = new CuentaAhorros(120345, 'A', 1000);
        cuenta.deposito(200);
        cuenta.retiro(100);
        cuenta.imprimirCuenta();

        CuentaHabiente cliente = new CuentaHabiente("Ana Lopez", "Av. Reforma 10", "5550101");
        CuentaCheques cheques = new CuentaCheques(120346, 'C', 900, 300);
        CuentaInversion inversion = new CuentaInversion(120347, 'I', 5000, 8.5, "2026-08-28");
        cliente.agregarCuenta(cuenta);
        cliente.agregarCuenta(cheques);
        cliente.agregarCuenta(inversion);
        cliente.agregarCuenta(cuenta);
        System.out.println("Consulta: " + cliente.consultarCuenta(120346).descripcionDeLaCuenta());
        cliente.listarCuentas();

        cheques.retiro(1100);
        cheques.retiro(500);
        cheques.imprimirCuenta();

        try {
            cuenta.retiro(5000);
        } catch (SaldoInsuficienteException exception) {
            System.out.println(exception.getMessage());
        }
        try {
            inversion.retiro(100);
        } catch (OperacionInvalidaException exception) {
            System.out.println(exception.getMessage());
        }
        inversion.setFechaAlta(LocalDate.now().minusMonths(6));
        inversion.calculaVigencia();
        inversion.imprimirCuenta();
        cliente.eliminarCuenta(120346);

        Banco banco = new Banco("Banco Electronico", "Centro 1", "5550000");
        banco.altaCliente(cliente);
        banco.imprimirClientes();
        banco.actualizaCliente("Centro 2");
        System.out.println(banco);
    }
}