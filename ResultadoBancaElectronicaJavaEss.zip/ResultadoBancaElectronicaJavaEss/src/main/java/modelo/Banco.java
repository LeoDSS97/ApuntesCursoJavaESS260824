package modelo;

import java.util.ArrayList;
import java.util.List;

public class Banco implements ManejaClientes {
    private String nombre;
    private String domicilio;
    private String telefono;
    private final List<CuentaHabiente> clientes;

    public Banco(String nombre, String domicilio, String telefono) {
        this.nombre = nombre;
        this.domicilio = domicilio;
        this.telefono = telefono;
        this.clientes = new ArrayList<>();
    }

    @Override
    public void altaCliente(CuentaHabiente cliente) {
        if (cliente != null && consultaCliente(cliente.getNumeroCliente()) == null
                && consultaClientePorRfc(cliente.getRfc()) == null) {
            clientes.add(cliente);
        }
    }

    @Override
    public void bajaCliente(int numero) {
        CuentaHabiente cliente = consultaCliente(numero);
        if (cliente != null) {
            clientes.remove(cliente);
        }
    }

    @Override
    public CuentaHabiente consultaCliente(int numero) {
        for (CuentaHabiente cliente : clientes) {
            if (cliente.getNumeroCliente() == numero) {
                return cliente;
            }
        }
        return null;
    }

    public CuentaHabiente consultaClientePorRfc(String rfc) {
        for (CuentaHabiente cliente : clientes) {
            if (cliente.getRfc().equalsIgnoreCase(rfc)) {
                return cliente;
            }
        }
        return null;
    }

    @Override
    public void actualizaCliente(String domicilio) {
        this.domicilio = domicilio;
    }

    public void imprimirClientes() {
        clientes.forEach(System.out::println);
    }

    public List<CuentaHabiente> getClientes() { return List.copyOf(clientes); }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDomicilio() { return domicilio; }
    public String getTelefono() { return telefono; }

    @Override
    public String toString() {
        return String.format("Banco{nombre='%s', domicilio='%s', telefono='%s', clientes=%d}",
                nombre, domicilio, telefono, clientes.size());
    }
}