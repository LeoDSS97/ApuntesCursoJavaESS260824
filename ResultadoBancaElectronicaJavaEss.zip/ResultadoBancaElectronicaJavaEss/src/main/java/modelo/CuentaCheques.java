package modelo;

public class CuentaCheques extends Cuenta {
    private double proteccion;

    public CuentaCheques(int numeroCuenta, char tipoCuenta, double saldo, double proteccion) {
        super(numeroCuenta, tipoCuenta, saldo);
        this.proteccion = proteccion;
    }

    @Override
    public double retiro(double cantidad) {
        validarCantidad(cantidad);
        if (cantidad <= saldo) {
            return super.retiro(cantidad);
        }
        System.out.println("Operacion por sobre el valor disponible.");
        if (cantidad <= saldo + proteccion) {
            saldo -= cantidad;
            reportarOperacion("retiro", cantidad);
            return cantidad;
        }
        double penalizacion = cantidad * 0.10;
        saldo -= penalizacion;
        System.out.printf("Cheque rechazado. Penalizacion: %.2f%n", penalizacion);
        return 0;
    }

    @Override
    public void imprimirCuenta() {
        super.imprimirCuenta();
        System.out.printf("Proteccion de sobregiro: %.2f%n", proteccion);
    }

    public double getProteccion() { return proteccion; }
    public void setProteccion(double proteccion) { this.proteccion = proteccion; }

    @Override
    public String descripcionDeLaCuenta() {
        return "Cuenta de cheques";
    }
}