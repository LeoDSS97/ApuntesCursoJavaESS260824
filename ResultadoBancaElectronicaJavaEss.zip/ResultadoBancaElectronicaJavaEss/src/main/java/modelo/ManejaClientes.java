package modelo;

public interface ManejaClientes {
    void altaCliente(CuentaHabiente cliente);
    void bajaCliente(int numero);
    CuentaHabiente consultaCliente(int numero);
    void actualizaCliente(String domicilio);
}