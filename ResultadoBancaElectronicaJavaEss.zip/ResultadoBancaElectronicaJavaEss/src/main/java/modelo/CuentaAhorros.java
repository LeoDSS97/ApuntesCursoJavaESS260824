package modelo;

public class CuentaAhorros extends Cuenta {
    public CuentaAhorros(int numeroCuenta, char tipoCuenta, double saldo) {
        super(numeroCuenta, tipoCuenta, saldo);
    }

    @Override
    public double retiro(double cantidad) throws SaldoInsuficienteException {
        validarCantidad(cantidad);
        if (cantidad > saldo) {
            throw new SaldoInsuficienteException("No hay suficiente saldo para realizar el retiro");
        }
        return super.retiro(cantidad);
    }

    @Override
    public String descripcionDeLaCuenta() {
        return "Cuenta de ahorros";
    }
}