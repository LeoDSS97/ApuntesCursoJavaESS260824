package modelo;

import java.time.LocalDate;
import java.util.Scanner;

public class MenuBancaElectronica {
    private final Scanner scanner = new Scanner(System.in);
    private final Banco banco = new Banco("Banco Electronico", "Centro", "5550000");

    public static void main(String[] args) {
        new MenuBancaElectronica().iniciar();
    }

    private void iniciar() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opcion: ");
            try {
                ejecutarOpcion(opcion);
            } catch (RuntimeException exception) {
                System.out.println("Operacion no realizada: " + exception.getMessage());
            }
        } while (opcion != 0);
        scanner.close();
        System.out.println("Sesion terminada.");
    }

    private void mostrarMenu() {
        System.out.println("\n=== BANCA ELECTRONICA ===");
        System.out.println("1. Agregar Clientes");
        System.out.println("2. Eliminar Clientes");
        System.out.println("3. Mostrar Clientes");
        System.out.println("4. Buscar Cliente");
        System.out.println("5. Modificar cliente");
        System.out.println("6. Operaciones");
        System.out.println("0. Salir");
    }

    private void ejecutarOpcion(int opcion) {
        switch (opcion) {
            case 1 -> agregarCliente();
            case 2 -> eliminarCliente();
            case 3 -> banco.imprimirClientes();
            case 4 -> buscarCliente();
            case 5 -> modificarCliente();
            case 6 -> operaciones();
            case 0 -> { }
            default -> System.out.println("Opcion no valida.");
        }
    }

    private void agregarCliente() {
        int numero = leerEntero("Numero cliente: ");
        String rfc = leerTexto("RFC: ");
        CuentaHabiente cliente = new CuentaHabiente(numero, rfc,
                leerTexto("Nombre: "), leerTexto("Domicilio: "), leerTexto("Telefono: "));
        banco.altaCliente(cliente);
        System.out.println("Cliente agregado.");
    }

    private void eliminarCliente() {
        int numero = leerEntero("Numero cliente a eliminar: ");
        banco.bajaCliente(numero);
        System.out.println("Solicitud de baja procesada.");
    }

    private void buscarCliente() {
        System.out.println("1. Numero cliente");
        System.out.println("2. RFC");
        int criterio = leerEntero("Seleccione criterio: ");
        CuentaHabiente cliente = criterio == 1
                ? banco.consultaCliente(leerEntero("Numero cliente: "))
                : banco.consultaClientePorRfc(leerTexto("RFC: "));
        imprimirResultado(cliente);
    }

    private void modificarCliente() {
        CuentaHabiente cliente = obtenerCliente();
        if (cliente == null) {
            return;
        }
        System.out.println("1. Agregar cuenta");
        System.out.println("2. Cancelar cuenta");
        int opcion = leerEntero("Seleccione una accion: ");
        if (opcion == 1) {
            cliente.agregarCuenta(crearCuenta());
            System.out.println("Cuenta agregada o ignorada si ya existia.");
        } else if (opcion == 2) {
            int numeroCuenta = leerEntero("Numero de cuenta a cancelar: ");
            System.out.println(cliente.eliminarCuenta(numeroCuenta)
                    ? "Cuenta cancelada." : "Cuenta no encontrada.");
        } else {
            System.out.println("Accion no valida.");
        }
    }

    private void operaciones() {
        CuentaHabiente cliente = obtenerCliente();
        if (cliente == null) {
            return;
        }
        System.out.println("1. Retiro");
        System.out.println("2. Deposito");
        System.out.println("3. Listar cuentas");
        int opcion = leerEntero("Seleccione una operacion: ");
        if (opcion == 3) {
            cliente.listarCuentas();
            return;
        }
        Cuenta cuenta = cliente.buscarCuenta(leerEntero("Numero de cuenta: "));
        if (cuenta == null) {
            System.out.println("Cuenta no encontrada.");
            return;
        }
        double cantidad = leerDouble("Cantidad: ");
        if (opcion == 1) {
            cuenta.retiro(cantidad);
        } else if (opcion == 2) {
            cuenta.deposito(cantidad);
        } else {
            System.out.println("Operacion no valida.");
        }
    }

    private CuentaHabiente obtenerCliente() {
        int numero = leerEntero("Numero cliente: ");
        CuentaHabiente cliente = banco.consultaCliente(numero);
        imprimirResultado(cliente);
        return cliente;
    }

    private Cuenta crearCuenta() {
        int numero = leerEntero("Numero de cuenta: ");
        char tipo = Character.toUpperCase(leerTexto("Tipo (A=ahorros, C=cheques, I=inversion): ").charAt(0));
        double saldo = leerDouble("Saldo inicial: ");
        if (tipo == 'C') {
            return new CuentaCheques(numero, tipo, saldo, leerDouble("Proteccion de sobregiro: "));
        }
        if (tipo == 'I') {
            return new CuentaInversion(numero, tipo, saldo, leerDouble("Tasa semestral: "));
        }
        return new CuentaAhorros(numero, tipo, saldo);
    }

    private void imprimirResultado(CuentaHabiente cliente) {
        System.out.println(cliente == null ? "Cliente no encontrado." : cliente);
    }

    private String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine().trim();
    }

    private int leerEntero(String mensaje) {
        return Integer.parseInt(leerTexto(mensaje));
    }

    private double leerDouble(String mensaje) {
        return Double.parseDouble(leerTexto(mensaje));
    }
}