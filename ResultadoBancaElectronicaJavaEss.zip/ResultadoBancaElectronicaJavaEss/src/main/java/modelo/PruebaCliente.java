package modelo;

public class PruebaCliente {
    public static void main(String[] args) {
        CuentaHabiente cliente = new CuentaHabiente("Luis Perez", "Calle 1", "5550202");
        CuentaAhorros cuenta = new CuentaAhorros(220001, 'A', 1500);

        System.out.println("Cuenta agregada: " + cliente.agregarCuenta(cuenta));
        System.out.println("Cuenta repetida: " + cliente.agregarCuenta(cuenta));
        System.out.println("Consulta encontrada: " + (cliente.consultarCuenta(220001) != null));
        cliente.listarCuentas();
        System.out.println("Cuenta eliminada: " + cliente.eliminarCuenta(220001));
        System.out.println("Cuenta restante: " + cliente.getCuentas().size());
    }
}