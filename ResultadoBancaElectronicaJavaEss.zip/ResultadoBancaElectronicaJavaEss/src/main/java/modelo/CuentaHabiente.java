package modelo;

import java.util.ArrayList;
import java.util.List;

public class CuentaHabiente {
    private int numeroCliente;
    private String rfc;
    private String nombre;
    private String domicilio;
    private String telefono;
    private final List<Cuenta> cuentas;

    public CuentaHabiente(String nombre, String domicilio, String telefono) {
        this(0, "", nombre, domicilio, telefono);
    }

    public CuentaHabiente(int numeroCliente, String rfc, String nombre, String domicilio, String telefono) {
        this.numeroCliente = numeroCliente;
        this.rfc = rfc;
        this.nombre = nombre;
        this.domicilio = domicilio;
        this.telefono = telefono;
        this.cuentas = new ArrayList<>();
    }

    public boolean agregarCuenta(Cuenta cuenta) {
        if (cuenta == null || buscarCuenta(cuenta.getNumeroCuenta()) != null) {
            return false;
        }
        return cuentas.add(cuenta);
    }

    public Cuenta consultarCuenta(int numero) {
        return buscarCuenta(numero);
    }

    public boolean eliminarCuenta(int numero) {
        Cuenta cuenta = buscarCuenta(numero);
        return cuenta != null && cuentas.remove(cuenta);
    }

    public Cuenta buscarCuenta(int numero) {
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getNumeroCuenta() == numero) {
                return cuenta;
            }
        }
        return null;
    }

    public void listarCuentas() {
        cuentas.forEach(Cuenta::imprimirCuenta);
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDomicilio() { return domicilio; }
    public void setDomicilio(String domicilio) { this.domicilio = domicilio; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public List<Cuenta> getCuentas() { return List.copyOf(cuentas); }
    public int getNumeroCliente() { return numeroCliente; }
    public void setNumeroCliente(int numeroCliente) { this.numeroCliente = numeroCliente; }
    public String getRfc() { return rfc; }
    public void setRfc(String rfc) { this.rfc = rfc; }

    @Override
    public String toString() {
        return String.format("CuentaHabiente{numero=%d, rfc='%s', nombre='%s', domicilio='%s', telefono='%s', cuentas=%d}",
            numeroCliente, rfc, nombre, domicilio, telefono, cuentas.size());
    }
}