package modelo;

import java.time.LocalDate;

public class CuentaInversion extends Cuenta {
    private final double tasaInteresSemestral;
    private final LocalDate fechaApertura;

    public CuentaInversion(int numeroCuenta, char tipoCuenta, double saldo,
                           double tasaInteresSemestral) {
        super(numeroCuenta, tipoCuenta, saldo);
        this.tasaInteresSemestral = tasaInteresSemestral;
        this.fechaApertura = LocalDate.now();
    }

    @Override
    public void deposito(double cantidad) throws OperacionInvalidaException {
        throw new OperacionInvalidaException("No se permiten depositos durante el periodo de inversion");
    }

    @Override
    public double retiro(double cantidad) throws OperacionInvalidaException {
        if (calculaVigencia() < 6) {
            throw new OperacionInvalidaException("Aun no se pueden realizar retiros; deben pasar 6 meses");
        }
        return super.retiro(cantidad);
    }

    @Override
    public void imprimirCuenta() {
        super.imprimirCuenta();
        System.out.printf("Fecha de apertura: %s, Tasa semestral: %.2f%%, Intereses a ganar: %.2f%n",
                fechaApertura, tasaInteresSemestral, saldo * tasaInteresSemestral / 100);
    }

    public double getTasaInteresSemestral() { return tasaInteresSemestral; }
    public LocalDate getFechaApertura() { return fechaApertura; }

    @Override
    public String descripcionDeLaCuenta() {
        return "Cuenta de inversion a seis meses";
    }
}