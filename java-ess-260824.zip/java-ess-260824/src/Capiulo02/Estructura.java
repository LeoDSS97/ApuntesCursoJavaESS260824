//Java de forma predeterminada pone todo en un paquete default

//Los archivos de Java pueden comenzar con la línea del paquete
package Capiulo02;

//Sección de importaciones opcional
//Mando traer toda una clase para estarla utilizando

//Mando traer los métodos de una clase
//el símbolo de * representa un atajo para poner varios valores de forma
//implicita


public class Estructura extends Object{

    //La palabra static indica miembros de clase
    // cantidad de objetos por ejemplo
    static int compartido = 0;
    //La ausencia de la palabra static indica miembros de instancia
    //id del objeto
    int individual = 0;

    //Bloques de inicialización (no son muy utilizados en la práctica)

    // los estaticos que van primero
    static {
        System.out.println("Se ha cargado en memoria la clase Estructura");
    }

    // los normales que van despues de los estaticos
    {
        System.out.println("La JVM quiere generar un objeto de la clase estructura");
    }



    //Metodo especial llamado constructor debe coincidir en nombre con la clase
    // y no debe listar ningun tipo de retorno
    public Estructura() {
        //La primera línea siempre es un llamado a otros constructores.
        // super()    / this()
        compartido++;
        this.individual = compartido;
        System.out.println("Se ha creado un objeto");
    }

    //De forma predeterminada JAVA siempre genera un constructor default
    /* De poner un constructor de forma explícita JAVA ya no genera el default
    * public Estructura(){
    *   super()           este llamado va a Object
    * }
    * */


}
