package Capiulo02;

//Idealmente en java por cada archivo (Inicio.java) nosotros deberiamos tener solo
//una clase, podemos definir varias en uno solo pero solo la principal(la que se
// llama como el archivo solo ella puede tener modificadores de acceso)
public class  Inicio {

    //Las clases internas estas si pueden llevar los modificadores de acceso
    public class InternaInicio{}
    public static void main(String[] args) {

        Estructura obj1 = new Estructura();
        System.out.println("obj1 = " + obj1.individual);
        Estructura obj2 = new Estructura();
        System.out.println("obj2 = " + obj2.individual);
        Estructura obj3 = new Estructura();
        System.out.println("obj3 = " + obj3.individual);

        System.out.println("**************************+");

        System.out.println("Estructura: " + Estructura.compartido);
        System.out.println(obj3.compartido);

    }


}


class externaInicio{
}