package Capitulo11;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

public class Inicio {

    public static void main(String[] args) {
        //ejemploFecha();
        //ejemplosCreacionLocalDate();
        //ejemplosCreacionLocalTime();
        ejemplosCreacionZonedDateTime();
    }

    public static void ejemploMutableEInmutable(){
        StringBuilder prueba = new StringBuilder();
        ArrayList<String> prueba_lineas = new ArrayList<>();

        prueba.append("ABCD");

        prueba_lineas.add("A");
        prueba_lineas.add("B");
        prueba_lineas.add("C");
        prueba_lineas.add("D");

        //SB = ABCD     AL = A,B,C,D
        //Mutable mutable = new Mutable(prueba, prueba_lineas);
        Mutable ya_no_tan_mutable = new Mutable();
        ya_no_tan_mutable.setSb(prueba);
        ya_no_tan_mutable.setList(prueba_lineas);



        //[ABCDAgregamos en intermedia]
        Intermedia.operacionesSB(prueba);

        //Inicio, A,B,C,D, Intermedio, Final
        Intermedia.operacionesArrayList(prueba_lineas);

        var resultado_SB = ya_no_tan_mutable.getSb();
        System.out.println("prueba_lineas = " + prueba_lineas);
        System.out.println("resultado_SB = " + resultado_SB);
        var resultado_AL = ya_no_tan_mutable.getList();
        System.out.println("prueba_lineas = " + prueba_lineas);
        System.out.println("resultado_AL = " + resultado_AL);



        //Patron de diseño de Builder
        //No usamos un metodo constructor directamente
        //Usamos varios metodos estaticos, que internamente se mandan llamar
        //entre si, poco a poco establecen los campos y valores para generar
        // el objeto internamente (constructor privado)
    }

    public static void ejemploFecha(){
        //Now siempre nos devuelve la información actual
        LocalDate hoy = LocalDate.now();
        System.out.println("hoy = " + hoy);
        LocalDate ayer = hoy.minusDays(1);
        System.out.println("ayer = " + ayer);
        LocalDate manana = hoy.plusDays(1);
        System.out.println("manana = " + manana);
        System.out.println("hoy = " + hoy);
    }

    public static void ejemplosCreacionLocalDate(){
        //Metodo of con solamente enteros
        LocalDate hoy_metodo_of_int = LocalDate.of(2026, 8, 27);
        //Metodo of con Enum Month enteros
        LocalDate hoy_metodo_of_Enum = LocalDate.of(2026, Month.AUGUST, 27);

        LocalDate hoy_metodo_of_epoch = LocalDate.ofEpochDay(20692L);
        System.out.println(hoy_metodo_of_epoch);
        
        //Parse toma una cadena "formateada" que representa una fecha
        //en un formato predeterminado (ISO)
        LocalDate fecha_texto = LocalDate.parse("2026-08-27");
        System.out.println("fecha_texto = " + fecha_texto);

        //parse con un formateador de fechas
        //definimos nuestro propio formato personalizado
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        //Usamos nuestro formato para estar convirtiendo los datos
        fecha_texto = LocalDate.parse("27/08/2026", formato);
        //Usamos nuestro formato para imprimir
        System.out.println("fecha_texto = " + fecha_texto.format(formato) + " con formato aplicado");

        LocalDate fecha = LocalDate.now();

        DateTimeFormatter fecha_oficio = DateTimeFormatter.ofPattern("dd ' del mes ' MMMM ' del año ' yyyy");
        System.out.println(fecha.format(fecha_oficio));
        //Originalmente teniamos un objeto fecha = 27/08/26
        //Dos objetos fecha uno 27/08/26 y otro con el 28/08/26
        //4 objetos los nuevos son 28/12/26 y 28/12/27
        // el ultimo objeto es el de 25/12/27
        var resultado = fecha.plusDays(1).plusMonths(4).plusYears(1).minusDays(3);
        System.out.println("resultado.format(fecha_oficio) = " + resultado.format(fecha_oficio));

        //Los objetos de Periodo representan cantidades de fechas empaquetadas para
        //reutilizarse en operaciones de tiempos
        Period bimestre = Period.of(0,2,0);
        Period semestre = Period.of(0,6,0);
        Period lustro = Period.of(5,0,0);
        resultado = resultado.plus(bimestre).plus(semestre).plus(lustro);
        System.out.println("resultado.format(fecha_oficio) = " + resultado.format(fecha_oficio));
        resultado = resultado.plus(1, ChronoUnit.DECADES);
        System.out.println("resultado.format(fecha_oficio) = " + resultado.format(fecha_oficio));
        resultado = resultado.withYear(2026);
        System.out.println("resultado.format(fecha_oficio) = " + resultado.format(fecha_oficio));
        System.out.println(resultado.toEpochDay());
        //Un instante representa un momento especifico en el tiempo y universal
        //Para los registros  logs
        //LocalDate.ofInstant();
    }

    public static void ejemplosCreacionLocalTime(){
        //Metodo of con solamente enteros
        LocalTime ahora_metodo_of = LocalTime.of(15, 20);
        LocalTime ahora_metodo_ofSecond = LocalTime.ofSecondOfDay(31692L);
        System.out.println(ahora_metodo_ofSecond);
        var hora_actual = LocalTime.now();
        System.out.println("hora_actual = " + hora_actual);
        //Parse toma una cadena "formateada" que representa una hora
        //en un formato predeterminado (ISO)
        LocalTime hora_texto = LocalTime.parse("09:05:27");
        System.out.println("hora_texto = " + hora_texto);
        //parse con un formateador de fechas
        //definimos nuestro propio formato personalizado
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("HH mm ss");
        //Usamos nuestro formato para estar convirtiendo los datos
        //hora_texto = LocalTime.parse("090527", formato);
        //Usamos nuestro formato para imprimir
        //System.out.println("fecha_texto = " + hora_texto.format(formato) + " con formato aplicado");
        var resultado = hora_actual.plusHours(1).plusMinutes(16).plusSeconds(1).minusMinutes(3);
        System.out.println("resultado = " + resultado);

        //Los objetos de Periodo representan cantidades de fechas empaquetadas para
        //reutilizarse en operaciones de tiempos
        Duration media_hora = Duration.of(30, ChronoUnit.MINUTES);
        Duration cuarto_hora = Duration.of(15, ChronoUnit.MINUTES);
        Duration rato = Duration.of(2, ChronoUnit.HOURS);

        resultado = resultado.plus(media_hora).plus(cuarto_hora).plus(rato);

        System.out.println("resultado = " + resultado);
        resultado = resultado.withHour(20);
        System.out.println("resultado = " + resultado);
    }

    public static void ejemplosCreacionLocalDateTime(){

        LocalDateTime presente = LocalDateTime.now();
        System.out.println("presente = " + presente);
        //Un instante representa un momento especifico en el tiempo y universal
        //Para los registros  logs
        //LocalDate.ofInstant();
    }

    public static void ejemplosCreacionZonedDateTime(){
//        var zonas = ZoneId.getAvailableZoneIds();
//        for (String zona : zonas)
//        {
//            if(zona.contains("America")) {
//                System.out.println("zona = " + zona);
//            }
//        }
        // America/Cancun
        // America/Mazatlan
        // America/Mexico_City
        ZonedDateTime hora_mexico = ZonedDateTime.now(ZoneId.of("America/Mexico_City"));
        System.out.println("hora_mexico = " + hora_mexico);
        ZonedDateTime hora_mazatlan = ZonedDateTime.now(ZoneId.of("America/Mazatlan"));
        System.out.println("hora_mazatlan = " + hora_mazatlan);
        ZonedDateTime hora_cancun = ZonedDateTime.now(ZoneId.of("America/Cancun"));
        System.out.println("hora_cancun = " + hora_cancun);
        Instant actualidad = Instant.now();
        System.out.println("actualidad = " + actualidad);
        ZonedDateTime conversion_horario_mexico = ZonedDateTime.ofInstant(actualidad, ZoneId.of("America/Mexico_City"));
        System.out.println("conversion_horario_mexico = " + conversion_horario_mexico);
    }





}
