package Capitulo11;

public class Singleton {

    static int instancias = 0;

    private Singleton(){

    }
    public static Singleton crear(){
        if(instancias == 0)
        {
            new Singleton();
            instancias++;
        }
        return null;
    }
}
