package Capitulo11;

public class Inmutable {
}
