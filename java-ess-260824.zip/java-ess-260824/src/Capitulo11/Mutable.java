package Capitulo11;

import java.util.ArrayList;

public class Mutable {

    StringBuilder sb;
    ArrayList<String> list;

    public Mutable(StringBuilder sb, ArrayList<String> list) {
        this.sb = sb;
        this.list = list;
    }

    public StringBuilder getSb() {
        return new StringBuilder(sb);
    }

    public void setSb(StringBuilder sb) {

        this.sb = new StringBuilder(sb);
    }

    public ArrayList<String> getList() {
        return new ArrayList<>(list);
    }

    public void setList(ArrayList<String> list) {
        this.list = new ArrayList<>(list);
    }

    public Mutable() {
    }
}
