package Capitulo11;

import java.util.ArrayList;

public class Intermedia {

    public static void operacionesSB(StringBuilder sb){
        sb.append("Agregamos en intermedia");
        sb.insert(0, "[");
        sb.append("]");
    }

    public static void operacionesArrayList(ArrayList<String> palabras){
        palabras.add("Intermedio");
        palabras.add("final");
        palabras.add(0, "Inicio");
    }


}
