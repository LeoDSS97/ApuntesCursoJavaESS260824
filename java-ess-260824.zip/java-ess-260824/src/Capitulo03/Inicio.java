package Capitulo03;

public class Inicio {
    public static void main(String[] args) {
        char c = 'a';
        System.out.println("c = " + c);
        char cn = 97;
        System.out.println("cn = " + cn);

        // VAR es un tipo especial de dato que es para representar cualquiera de
        // Los tipos de datos que ofrece JAVA.
        var variable = 0; /*Depende del contenido var es reemplazado por el dato*/
        //las variables del tipo VAR forzosamente las tenemos que declarar e
        //inicializar, posteriormente debe mantener el mismo tipo.
        //Solamente funciona en un contexto local

        Estructura.ejemploStrings();
    }
}
