package Capitulo03;

public class Estructura {

    //Los atributos en JAVA
    //Para los atributos en JAVA por lo general se sigue un patrón de
    //Modificador de acceso / modificadores de comportamiento / tipo / variable
    //No hay mayor problema en los atributos con cambiar el orden de los primeros 2,
    //Con los metodos si son mas delicados.

    //Estaticos uno solo para todos
    //Cuando usamos final lo declaramos como una constante (MAYUSCULA)
    //public static final double PI = 3.1416;
    //public final static  double PI = 3.1416;
    final static public double PI = 3.1416;

    //Instancia cada uno su propia copia
    /*predeterminado paquete*/int edad = 0;
    String nombre = "Jhon Doe";

    //Tipos primitivos
    //Tipos de datos numericos
    byte b = 1;
    short s = (short)0L; /*Realziamos un casteo de forma explicita */
    int i = 1_000_000_000; /*De forma predeterminada asume que los
    numeros enteros son int*/
    //La unica regla del uso de los _ para simplificar la lectura es que no deben
    // de estar a los extremos ni tocar el punto decimal
    //int malo = 1__0_0____000_0_1;
    long l = 0L;

    //Sistemas de notacion binario (b) octal, hexadecimal

    int binario = 0B10101;
    int octal = 010101;
    int hexadecimal = 0X10101;

    float f = 1F;
    double d = 0; /*Los decimales son del tipo double*/
    double cientifica = 0E10;

    //JAVA intenta que el tipo de dato pequeño se convierta automaticamete en el
    //Mayor (predeterminado int) pero puede ser long o double o float
    short suma = (byte) (f + d);

    //Tipos de datos caracteres
    char c = 'a';
    char cn = 25;

    //Tipo booleano
    boolean boo = false;

    //Los primitivos son la forma sencilla de trabajar en llama
    //Existen versiones de objetos
    // Existe el autoboxing y el unboxing
    // si tenemos un primitivo pero necesitamos un objeto
    // short s -----> (Short S)
    // Short S -----> (short s)
    Short S;
    Byte B;
    Integer I;
    Long L;
    Float F;
    Double D;
    Character C;

    //JAVA permite en un solo renglon declarar multiples variables en un solo lugar
    //todas las variables van a ser del mismo tipo, pudiendo o no inicializar a cada
    // una de ellas
    int x = 1, y = 2, z = 3;
    //Pero puede generar cuestiones complejas al momento de leer el codigo
    int [] ldss,  ld [], ss[][];

    public static void ejemploStrings(){
        //String y StringBuilder
        String mensaje = "Hola mundo";
        StringBuilder compuesto = new StringBuilder("Hola mundo compuesto");

        //Bloques de texto
        mensaje =
                """
                Este es un mensaje usando un bloque de texto donde %s
                solamente hay dos lineas de texto y no hay una sangria
                %d
                """.formatted("esto fue insertado", 2026);
        System.out.println(mensaje);

        String mensajeOriginal = "Hola";
        String segundoMensaje = new String("hola");
        //Igualdad de referencias (no sabemos si el contenido es realmente el mismo)
        System.out.println("Son el mismo objeto?" + (mensajeOriginal == segundoMensaje));
        System.out.println("Son el mismo objeto?" + (mensajeOriginal == segundoMensaje.intern()));

        //Igualdad de contenido equals() / hashCode()
        System.out.println("Son el mismo texto?" + (mensajeOriginal.equalsIgnoreCase(segundoMensaje)));



    }



    //Declarar un metodo
    //modificador de acceso / comportamiento / retorno / nombre
    public static int suma(/*Lista de parametros
    *la cantidad de numeros es variable */ int a, int b){
        return a + b;
    }



    //public es todos
    //protected es a los descendientes por herencia
    //paquete solamente en el mismo paquete
    //private solamente internamente



}
