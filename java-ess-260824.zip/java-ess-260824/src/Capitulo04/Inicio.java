package Capitulo04;

public class Inicio {
    public static void main(String[] args) {
//        validacionesLogicas(null);
//        validacionesLogicas("");
//        validacionesLogicas("      ");
//        validacionesLogicas("Hola mundo");
//        ejemploOperadorternario(null);
//        ejemploOperadorternario("");
//        ejemploOperadorternario("    ");
//        ejemploOperadorternario("Hola mundo");

        ejemploSwitchTradicionalConEnum();
    }

    public static void validacionesLogicas(String mensaje){
        //If else
        // Si vació == true || me ahorra ese posible error
        // Sin contenido == true || me ahorra preguntar si son solo blancos
        if(mensaje == null || mensaje.isEmpty() || mensaje.isBlank()){
            System.out.println("resultado: " + (mensaje == null || mensaje.isEmpty() || mensaje.isBlank()));
        }
        //Aquí van todos los datos que no cumplieron la condición de arriba
        else{
            System.out.println("mensaje = " + mensaje);
        }
    }

    public static void ejemploOperadorternario(String mensaje){
        String texto = (mensaje == null || mensaje.isEmpty() || mensaje.isBlank()) ? "El texto no es valido" : "El texto es valido";
        System.out.println("texto = " + texto);
    }

    public static void ejemploSwitchTradicionalConEnum(){

        var variable = Semana.LUNES;
        //variable = null;

        switch (variable){
            case LUNES:
                System.out.println("Otro lunes comenzando a trabajar");
                //break;
            case MARTES, MIERCOLES, JUEVES:
                System.out.println("Mediados de la semana pero ya casi viernes");
                //break;
            case VIERNES:
                System.out.println("YA ES VIERNES");
                //break;
            case SABADO, DOMINGO:
                System.out.println("VAMOS A SALIR");
                //break;
            default:
                System.out.println("No entendí que dijiste");
        }

    }

    public static void ejemploExpresionesSwitch(Semana dia){
        String mensaje;

        mensaje = switch (dia){
            case LUNES -> "Otro lunes comenzando a trabajar";
            case MARTES, MIERCOLES, JUEVES -> "Mediados de la semana pero ya casi viernes";
            case VIERNES -> "YA ES VIERNES";
            case SABADO, DOMINGO -> "VAMOS A SALIR";
        };
        System.out.println("mensaje = " + mensaje);
    }

    public static void ejemploExpresinonesSwitchNumeros(int opcion){
        String mensaje;

        mensaje = switch (opcion){
            case 1,2,3,4,5 -> "los primeros 5 numeros";
            case 6,7,8,9 -> "los otros 5 numeros";
            case 0 -> "no divisible";
            default -> "los numeros ya se comienzan a repetir";
        };
    }

}
