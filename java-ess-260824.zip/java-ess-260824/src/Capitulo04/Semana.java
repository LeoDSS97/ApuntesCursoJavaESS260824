package Capitulo04;

public enum Semana {

    LUNES{

    }, MARTES{

    }, MIERCOLES{

    }, JUEVES{

    }, VIERNES {

    }, SABADO{

    }, DOMINGO{

    };

    boolean laboral;

}
