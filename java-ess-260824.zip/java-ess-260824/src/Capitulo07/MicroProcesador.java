package Capitulo07;

public interface MicroProcesador {

    void calcular();
    void procesar();

    // Este metodo con su implementacion predeterminada, opaca o entra en
    // disputa con el metodo conflicto de la Interface MicroControlador
    public default void conflicto(){
        System.out.println("Metodo Procesador");
    }
}
