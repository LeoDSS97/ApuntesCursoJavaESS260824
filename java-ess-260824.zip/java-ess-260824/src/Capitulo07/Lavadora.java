package Capitulo07;

public class Lavadora extends ElectrodomesticoAbstracto{

    @Override
    public void encender() {
        System.out.println("Se prende girando una perilla");
    }

    @Override
    public void apagar() {
        System.out.println("Se apaga cuando termina un ciclo");
    }

    @Override
    public void actualizar() {
        System.out.println("Incluye nuevos modos de lavado");
    }

    @Override
    public void reparar() {
        System.out.println("Se ha limpiado las piezas para quitar residuos");
    }

    @Override
    public String toString() {
        return "";
    }
}
