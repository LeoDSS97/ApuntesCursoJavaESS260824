package Capitulo07;

public class BDSQLServer extends BD{
    @Override
    public void insertar(){
        System.out.println("Insertamos en una BD SQLServer");
    }
    @Override
    public void eliminar(){
        System.out.println("Eliminar en una BD SQLServer");
    }
    @Override
    public void actualizar(){
        System.out.println("Actualizar en una BD SQLServer");
    }
    @Override
    public void visualizar(){
        System.out.println("Visualizar en una BD SQLServer");
    }
}
