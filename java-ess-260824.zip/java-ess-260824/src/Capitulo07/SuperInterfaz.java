package Capitulo07;

public interface SuperInterfaz {
}
