package Capitulo07;

public class Microondas /*extends ElectrodomesticoAbstracto*/ implements MicroControlador{
    //Manda un error si no he implementado los metodos abstractos que define
    //la super clase

    //Java ya identifica que hay implementaciones de los metodos abstractos
    public void actualizar(){
        System.out.println("Se han agregado nuevos modos para calentar alimentos");
    }
    public void apagar(){
        System.out.println("Se apaga  automáticamente cuando termina de calentar");
    }
    public void encender(){
        System.out.println("Se prende cuando el usuario hace clic en los botones de " +
                "tiempo o al darle en iniciar");
    }
    public void reparar(){
        System.out.println("Se han cambiado protección del microondas y sus sus piezas internas");
    }

    public String toString(){
        return "Soy un electrodomestico del tipo microondas.";
    }

    @Override
    public void calcular() {

    }

    @Override
    public void procesar() {

    }
}
