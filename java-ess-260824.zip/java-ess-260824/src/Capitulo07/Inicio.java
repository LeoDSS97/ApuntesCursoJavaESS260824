package Capitulo07;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Consumer;
public class Inicio {

    public static void main(String[] args) {
        //MicroControlador microondas = new Microondas();
//        microondas.encender();
//        microondas.actualizar();
//        microondas.reparar();
//        microondas.apagar();
//        microondas.conflicto();
//        microondas.digitar("Hola mundo");
//
//        ElectrodomesticoAbstracto auxiliar = new Refrigerador();
//        var resultado = auxiliar.getClass();
//        if(microondas instanceof MicroProcesador e)
//        {
//            System.out.println("Es un Electrodomestico");
//        }else{
//            System.out.println("No es un electrodomestico");
//        }
        ejemploClasesAnonimas();



//        var mensaje = "" + MicroControlador.CAMBIOMILENIO;
//        mensaje = microondas.CAMBIOMILENIO;
//        microondas.CAMBIOMILENIO = "01/01/2000";
    }

    public static void ejemploHerenciaConComputadora(){
        Electrodomestico computadora = new Computadora();
        System.out.println("computadora = " + computadora);
        //computadora.iniciarSesion("leonardo.sanchez@netec.com.mx", "password");
        computadora.encender();
        System.out.println("\n\n\n******************************\n\n\n");
        computadora.apagar();
        //Con computadora del tipo Computadora
        //1,2,3,A,B,C
        //Con computadora del tipo Electrodomestico
        //A,B,C
        //computadora.
        //Metodo estatico no necesita o no depende de un objeto
        //Depende de una plantilla
        computadora.actualizar();
        //El dia de hoy estemos usando una BD (MySQL) -----> Oracle / Postgre / SQLServer
        //Definir nuestra variable del tipo mas grande que se pueda
        BD miBaseDatos= new BDSQLServer();
        miBaseDatos.insertar();
        miBaseDatos.eliminar();
        miBaseDatos.actualizar();
        miBaseDatos.visualizar();
        //Este metodo solo funcionaria con el tipo de dato especifico
        //miBaseDatos.metodoEspecial();
        //Computadora laptop = new Computadora("Intel i7", "16 RAM", "1 TB HDD", "512 SDD", "NVIDIA RTX 2060");

    }

    public static void ejemplosHerenciaPrevioJAVA17()
    {
        //Previo a Java 17 solamente podiamos usar la plabra final y con
        //eso evitar la herencia para todas las clases


        //Desde JAVA 16 y oficializado en JAVA 17 las clases selladas
        //las clases selladas obligan a listar que descendientes directos tiene
        //una clase o interfaz y esos mismos tienen que ser finales, sellados o no
        //sellados para poder compilar el codigo.

        Abuela persona = new Hija();
        persona.cocinar();
        persona.cocinar("Agua Manantial", "Chiles", "Carne", "Vino", "Canela", "Sal", "Azucar");
        persona.cocinar("Agua", "Chiles", new String []{"Carne","Verduras", "Frutas", "Cereales"});
    }


    public static void ejemploList(){
        List<String> lista;
        lista = new ArrayList<>();
        lista = new LinkedList<>();
    }


    public static void ejemploClasesAnonimas(){
        // No puedes generar objetos de una interfaz o clase abstracta
        //Maniqui m1 = new Maniqui();

        //Puedes generar objetos que extiendan o implementar a elementos
        //Abstractos
        var m2 = new Maniqui() {
            @Override
            public void posar() {
                System.out.println("Pose del hombre pensador");
            }

            @Override
            public void girar() {
                System.out.println("El maniqui esta encorvado como si estuviese pensado");
            }
            public void saludar(){
                System.out.println("Saludamos a los visitantes con un sonido");
            }

        };

        m2.girar();
        m2.posar();
        m2.saludar();

        var m3 = new Maniqui() {
            @Override
            public void posar() {
                System.out.println("Hombre de Vitruvio ");
            }

            @Override
            public void girar() {
                System.out.println("Gira para demostrar el funcionamiento de sus articulaciones");
            }

            public void observar(){
                System.out.println("Te estoy vigilando");
            }

        };

        m3.girar();
        m3.posar();
        m3.observar();

    }

}
