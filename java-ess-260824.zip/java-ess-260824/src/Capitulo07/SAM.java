package Capitulo07;

//SAM -> Single Abstract Method
//Solo tienen un metodo abstracto
@FunctionalInterface
public interface SAM {
    void accion();
}
