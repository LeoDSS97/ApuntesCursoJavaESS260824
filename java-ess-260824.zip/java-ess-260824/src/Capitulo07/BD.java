package Capitulo07;

public abstract class BD {
    //Los metodos abstractos no pueden estar en cualquier lugar.
    //Interfaces, Clases abstractas, Enum
    public abstract void insertar();
    public abstract void eliminar();
    public abstract void actualizar();
    public abstract void visualizar();


//    public void insertar(){
//        System.out.println("Insertamos en una BD");
//    }
//    public void eliminar(){
//        System.out.println("Eliminamos en una BD");
//    }
//    public void actualizar(){
//        System.out.println("Actualizamos en una BD");
//    }
//    public void visualizar(){
//        System.out.println("Visualizamos en una BD");
//    }
}
