package Capitulo07;

//Una clase abstract no puede tener objetos de ella
public abstract class ElectrodomesticoAbstracto implements MicroControlador, MicroProcesador{

    //Los metodos abstractos están pensados para ser sobreescritos
    //Obligar a que los descendientes tengan un comportamiento que ellos mismos
    //van a especificar
    public abstract void encender();
    public abstract void apagar();
    public abstract void actualizar();
    public abstract void reparar();

    //Si agregamos un nuevo metodo eventualmente podriamos generar varios
    //problemas de modificaciones al codigo previamente existe.

    public void reposar(){
        System.out.println("Esto es una implementación predeterminada");
    }


    // Los metodos que proporciona Object por lo general ya tienen implementaciones
    // basicas y que en dado caso se pueden marcar igualmente como abstractos y no
    // deberia haber mayor problema siempre y cuando estemos en un tipo que admita
    // los valores abstractos.
    @Override
    public abstract String toString();

    @Override
    public void calcular() {

    }

    @Override
    public void procesar() {

    }

    @Override
    public void conflicto() {
        //Con esta sintaxis estamos decantándonos por un metodo en
        //específico de alguna de las superclases
        //Microcontrolador es la que proporciona la definición del metodo.
        //MicroControlador.super.conflicto();
        //MicroProcesador es la que proporciona la definición del metodo.
        //MicroProcesador.super.conflicto();
        System.out.println("Metodo de Electrodomestico Abstracto");

    }

    // Al momento de implementar los metodos de distintas interfaces hay que tener
    // cuidado de los posibles conflictos entre los distintos metodos que se van a implementar
    // por que la implementacion proporcionada debe satisfacer a ambas deficiones o como minimo
    // dar prioridad a una de ellas.



}
