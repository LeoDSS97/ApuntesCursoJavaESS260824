package Capitulo07;

public final class Hija extends Madre{
}
