package Capitulo07;

public interface MicroControlador{
    // Las interfaces asumen cosas de sus atributos y de sus metodos
    // una plantilla reutilizable por varios, y que se espera que se utilicen
    // multiples de forma simultánea

    //Asume que todos sus metodos son publicos abstractos
    void calcular();
    void procesar();

    public default void conflicto(){
        System.out.println("Metodo Controlador");
    }
    // Todas las variables dentro de una interfaz pues se asume que serán
    // publicas, finales (CONSTANTES), estaticas
    String CAMBIOMILENIO = "31/12/1999";

    // Java ya no asume cosas de su modificador de acceso me permite definir un
    // metodo nuevo que puede ser o no sobreescrito por una clase que implemente a
    // la interfaz
    public default void digitar(String mensaje) {
        if (validar_default(mensaje)) {
            return;
        } else {
            System.out.println("Convertir una señal analogia a una señal digital");
            System.out.println("El mensaje convertido de analogico a digital es:");
            System.out.println("mensaje: " + mensaje.hashCode());
        }
    }

    //Desde java 9 aproximadamente Oracle introdujo los
    // metodos privados y estaticos en las interfaces
    private boolean validar_default(String mensaje){
        return (mensaje == null || mensaje.isBlank());
    }

    public static void metodo_auxiliar(MicroControlador micro){
        //otro_metodo_auxiliar
        System.out.println(micro.getClass());
    }

    // Estos metodos estan pensados como soporte para los metodos estaticos
    // normales de una interfaz
    private static void otro_metodo_auxiliar(){

    }

}
