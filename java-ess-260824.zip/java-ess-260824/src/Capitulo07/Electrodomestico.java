package Capitulo07;

//Todas las clases en JAVA son una extension de Object

public class Electrodomestico {

    //Bloques de inicializacion
    //Estatico
    static{
        System.out.println("Se ha cargado la clase Electrodomestico en memoria");
    }
    //Normal
    {
        System.out.println("Se esta utilizando a la clase Electromestico en un proceso" +
                "de creacion de objetos");
    }
    public Electrodomestico(){
        System.out.println("Se ha mandado llamar al constructor de la clase Electromestico");
    }

    //Object Define una serie de metodos y qué dichos métodos están disponibles para
    //que cualquier clase los pueda personalizar / modificando
    //Sobre escritura garantizar que efectivamente estemos
    //haciendo la sobre escritura solo ocurre con métodos normales
    //con los metodos estaticos no se puede llevar a cabo.
    @Override
    public String toString() {
        return super.toString();
    }

    protected void encender(){
        System.out.println("Estamos prendiendo");
    }

    protected void apagar(){
        System.out.println("Estamos apagando");
    }

    public static void actualizar(){
        System.out.println("Estamos actualizando un electromestico con nueva" +
                " tecnologia");
    }

    public void metodoA(){}
    public void metodoB(){}
    public void metodoC(){}



}
