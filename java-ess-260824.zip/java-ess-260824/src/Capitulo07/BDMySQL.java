package Capitulo07;

public class BDMySQL extends BD{
    @Override
    public void insertar(){
        System.out.println("Insertamos en una BD MySQL");
    }
    @Override
    public void eliminar(){
        System.out.println("Eliminamos en una BD MySQL");
    }
    @Override
    public void actualizar(){
        System.out.println("Actualizamos en una BD MySQL");
    }
    @Override
    public void visualizar(){
        System.out.println("Visualizamos en una BD MySQL");
    }

    public void metodoEspecial(){

    }
}
