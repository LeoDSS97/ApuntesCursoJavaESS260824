package Capitulo07;

public class Computadora extends Electrodomestico{

    private String cpu;
    private String ram;
    private String hdd;
    private String ssd;
    private String gpu;


    //Estatico
    static{
        System.out.println("Se ha cargado la clase Computadora en memoria");
    }
    //Normal
    {
        System.out.println("Se esta utilizando a la clase Computadora en un proceso" +
                "de creacion de objetos");
    }

    //Contructores
    public Computadora(){
        //Aquí se mande llamar al otro constructor y se pongan valores predeterminados
        this("intel", "8 RAM", "512 GB", "", "Integrados");
        System.out.println("Se esta mandando llamar al constructor predeterminado");
    }
    public Computadora(String cpu, String ram,String hdd, String ssd, String gpu){
        //Siempre hay una llamada a un constructor
        //super();
        //Indicamos el contexto adecuado de donde es que viene la variable
        //Vienen de la clase y no del metodo
        this.cpu = cpu; /*cuando no lo indicamos asumiremos el contexto mas local*/
        this.ram = ram;
        this.hdd = hdd;
        this.ssd = ssd;
        this.gpu = gpu;
        System.out.println("Se esta mandado llamar al constructor con parametros");
    }

    public String iniciarSesion(String usuario, String contrasena){
        //Validaciones......
        assert (contrasena.equals("N0m3los3")) : "La contraseña es incorrecta";
        //Deberiamos evitar codigos de estatus
        //Excepciones
        return "Bienvenido " + usuario;
    }
    public String getCpu() {
        return cpu;
    }
    public void setCpu(String cpu) {
        if (validarString(cpu)){
            return;
        }
        this.cpu = cpu;
    }
    public String getRam() {
        return ram;
    }
    public void setRam(String ram) {
        this.ram = ram;
    }
    public String getHdd() {
        return hdd;
    }
    public void setHdd(String hdd) {
        this.hdd = hdd;
    }
    public String getSsd() {
        return ssd;
    }
    public void setSsd(String ssd) {
        this.ssd = ssd;
    }
    public String getGpu() {
        return gpu;
    }
    public void setGpu(String gpu) {
        this.gpu = gpu;
    }

    public static boolean validarString(String cadena){
        return (cadena == null || cadena.isEmpty() || cadena.isBlank());
    }

    //La firma de los metodos es un poco mas flexible que la de las variables, pero
    //es mas compleja dicha estructura
    //modificador acceso/modificadores comportamientos /
    // Estas secciones pueden ir intercambiadas

    //tipo retorno / nombre / lista parametros / Excepciones
    static public boolean otroMetodo() /*Excepciones declaradas*/{
        return false;
    }

    @Override
    public String toString() {
        return "Computadora{" +
                "cpu='" + cpu + '\'' +
                ", ram='" + ram + '\'' +
                ", hdd='" + hdd + '\'' +
                ", ssd='" + ssd + '\'' +
                ", gpu='" + gpu + '\'' +
                '}';
    }

    //Nuestra propia version de prender y apagar
    //Reglas de sobre escritura metodos de instancia
    //MISMA FIRMA DEL METODO
    //El modificador de acceso debe ser igual o mas permisivo que el anterior

    @Override
    protected void encender(){
        System.out.println("Estamos prendiendo una computadora");
    }
    @Override
    public void apagar(){
        System.out.println("Estamos apagando una computadora");
    }


    //Ocultamiento de metodos
    public static void actualizar(){
        System.out.println("Estamos actualizando los drivers de una computadora" +
                " con nueva tecnologia");
    }


    public void metodo1(){}
    public void metodo2(){}
    public void metodo3(){}


}
