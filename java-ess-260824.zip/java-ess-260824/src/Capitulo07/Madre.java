package Capitulo07;

//Las clases selladas obligan que los descendientes marquen a su propia clase
//Final (cancelamos la herencia)
//Sealed (Hacemos testamento de quien se queda con la herencia)
//Non-sealed (Volver a permitir a todos)
public sealed class Madre extends Abuela permits Hija {
}
