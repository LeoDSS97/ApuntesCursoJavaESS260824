package Capitulo07;

public final class Hijastra{// extends Madre{
}
