package Capitulo07;

public class Mascota {
}
