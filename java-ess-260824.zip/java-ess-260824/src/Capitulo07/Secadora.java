package Capitulo07;

public class Secadora extends ElectrodomesticoAbstracto{

    @Override
    public void actualizar(){
        System.out.println("Tiene nuevos modos para trabajar con distintas telas");
    }

    @Override
    public  void apagar(){
        System.out.println("Se apaga automaticamente cuando termina un ciclo de secado");
    }

    @Override
    public void encender() {
        System.out.println("Se prende cuando usuario hace clic en los botones de tiempos");
    }

    @Override
    public void reparar(){
        System.out.println("Se han cambiado piezas internas");
    }

    @Override
    public String toString() {
        return "";
    }
}
