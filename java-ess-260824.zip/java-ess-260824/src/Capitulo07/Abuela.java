package Capitulo07;

public sealed class Abuela permits Madre, Tia{

    public void cocinar(){
        System.out.println("Es una sorpresa lo que estoy preparando");
    }

    public void cocinar(String ingrediente){
        System.out.println("Estoy preparando un guisado");
    }

    public void cocinar(String ingrediente, String agua){
        System.out.println("Estoy preparando una sopa");
    }
    public void cocinar(String ingrediente,String agua, String especias){
        System.out.println("Estoy preparando un platillo en especial");
    }
    public void cocinar(String agua, String especias, String [] ingredientes){
        System.out.println("Estoy preparando la cena de navidad");
    }
    //Argumentos variables
    //Recibimos 0+ parametros pues queremos un arreglo automatico para guardar
    //todos esos valores que pudiesemos recibir
    //Debe ser el ultimo parametro del metodo
    public void cocinar(String agua, String ... ingredientes ){
        System.out.println("Estoy preparando muchos platillos distintos");

    }


}
