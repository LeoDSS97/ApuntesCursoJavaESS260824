package Capitulo07;

public abstract class Maniqui {

    public abstract void posar();

    public abstract void girar();
}
