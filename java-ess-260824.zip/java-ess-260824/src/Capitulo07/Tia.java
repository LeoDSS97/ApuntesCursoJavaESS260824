package Capitulo07;

public non-sealed class Tia extends Abuela{
}
