package Capitulo07;

public class Refrigerador extends ElectrodomesticoAbstracto{

    @Override
    public void encender() {
        System.out.println("Siempre esta prendiendo, cuando se conecta a la corriente");
    }

    @Override
    public void apagar() {
        System.out.println("Se apaga cuando se desconecta del sumistro electrico");
    }

    @Override
    public void actualizar() {
        System.out.println("Ahora se conecta a internet para tener un inventario de que hay dentro");
    }

    @Override
    public void reparar() {
        System.out.println("Se han cambiado las piezas motor del ventilador para refrigerar devuelta");
    }

    public String toString(){
        return "Soy un electrodomestico del tipo refrigerador.";
    }


    @Override
    public void calcular() {

    }

    @Override
    public void procesar() {

    }
}
