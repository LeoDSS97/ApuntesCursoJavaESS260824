package Capitulo12;

public class NuevaExcepcionRuntime extends RuntimeException {

    public NuevaExcepcionRuntime() {
        super("El usuario cometio un error");
    }
}
