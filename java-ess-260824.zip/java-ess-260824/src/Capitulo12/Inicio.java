package Capitulo12;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Connection;


public class Inicio {
    public static void main(String[] args) throws Exception {
        System.out.println("Estamos antes de hechar todo a perder");
        //ejemploChecked();

        //Try with resources
        // try (declaramos objetos que hagan uso del metodo close)
        try (Puerta puerta_1 = new Puerta();
             Puerta puerta_2 = new Puerta();
             Puerta puerta_3 = new Puerta();
             Puerta puerta_4 = new Puerta();
             Puerta puerta_5 = new Puerta()) {
            System.out.println("Probamos");
            System.out.println("Hay un error");
            throw new RuntimeException();
        } catch (RuntimeException e) {
            System.out.println("Lidiamos con el error original");
            System.out.println("Nuevo error");
            //System.exit(1);
            throw  new RuntimeException();
        }
        // Tenemos ahora un finally implicito
        /*finally{
            puerta_5.close();
            puerta_4.close();
            puerta_3.close();
            puerta_2.close();
            puerta_1.close();
        * }*/
        finally {
            //En  teoria siempre se va a ejecutar
            //Lo podemos utilizar para cerrar recursos
            //Conexion a BD, un Stream de datos
            //Otro recurso que tenga un metodo llamado Close();
            System.out.println("Fin");

        }








    }
    public static void ejemploError(){
        //Un error
        new ErrorCargaClase();
    }

    public static void ejemploRuntime(){
        //Excepcion del tipo RUntime
        var division = 1/(1-1);
    }

    public static void ejemploChecked() /*throws  IOException*/{
        //Declaramos en la firma del metodo que dicho metodo puede lanzar un error
        //InputStream is = new InputStream() {
        //    @Override
            //Declaramos que puede haber un error y le transferimos la responsabilidad
            //al invocador de dicho metodo
        //    public int read() throws IOException {
        //        return 0;
        //    }
        //};
        //is.read();

        //Lidiamos con el tipo de error que sabemos va a lanzar el metodo
        try {
            //Nuestro cuerpo problematico
            // Lanzar una exception
            System.out.println("Estamos dentro del metodo ejemploChecked ");
            System.out.println("Estamos dentro de la sección del try");
            var error = new Exception("Excepcion en el metodo de pruebas");
            error.initCause(new Throwable("Estamos probando los limites del sistema"));
            throw error;
        }
        catch(Exception /*Los tipos anteriores a la variable indican los posibles
         tipos de errores que vamos a lidiar con ellos*/ e){
            //Como lidiamos con el error
            System.out.println("Hubo un error en el metodo main con una excepcion");
            System.out.println("Estamos en el catch de Exception");
            System.out.println("Causa: "+ e.getCause());
            System.out.println("Mensaje del fallo: " + e.getMessage());
//            System.out.println("*************************************************");
//            System.err.println("Hubo un error en el metodo main con una excepcion");
//            System.err.println("Estamos en el catch de Exception");
//            System.err.println("Causa: "+ e.getCause());
//            System.err.println("Mensaje del fallo: " + e.getMessage());
        }
        finally {
            // Sea como sea que hayan pasado las cosas que hacemos al final
            System.out.println("El programa ha terminado");
        }
    }

    public static void ejemploOutOfMemoryErro(){
        var lista = new ArrayList<String>();
        //Sintaxis valida logica no muy valida
        for(int i = 0;;i++){
            lista.add(""+ i);
        }
    }

    public static void ejemploIndexOutOfBoundsException(){
        var resultado = new int[5];
        var aux = resultado[5];
    }

    public static void ejemplosComportamientosExcepciones() throws Exception{
        RuntimeException excepcionNoChecada = new NuevaExcepcionRuntime();
        Exception excepcionChecada = new NuevaExcepcionChecada();

        var aleatorio = (int)(Math.random()*1000);
        if(aleatorio % 2 == 0)
        {
            throw excepcionChecada;
        }
        else{
            throw excepcionNoChecada;
        }
    }

    public static void ejemplosMulticatch(){
        //La estructura try - catch - finally minimo pide dos partes
        // try + catch
        // try + finally
        // try + catch + catch + finally    --> Distintos errores ---> Distintas soluciones
//        try{
//            var diviriendo = 0;
//            var divisor = 0;
//            var resultado = diviriendo / divisor;
//
//            if(resultado > 0){
//                throw new IOException();
//            }
//            else if (resultado == 0){
//                throw new SQLException();
//            }else {
//                throw new NuevaExcepcionChecada();
//            }
//        }
//        catch (RuntimeException e){
//            System.out.println("Algo malio sal");
//        }
//        catch (IOException e){
//            System.out.println("Hubo un problema con la entrada o salida de la informacion");
//        }
//        catch (SQLException e){
//            System.out.println("Hubo un error con la Base de datos");
//        }
//        catch (NuevaExcepcionChecada e){
//            System.out.println("Hubo un error con nuestro programa");
//        }
//        catch (Exception e){
//            System.out.println("Hubo un error");
//        }




        // try + multicatch + catch + finally   --> Distintos errores ---> Mismas soluciones

        try{
            var diviriendo = 0;
            var divisor = 0;
            var resultado = diviriendo / divisor;

            if(resultado > 0){
                throw new IOException();
            }
            else if (resultado == 0){
                throw new SQLException();
            }else {
                throw new NuevaExcepcionChecada();
            }
        }
        //Multicatch Distintos tipos de errores una misma solucion
        catch (IOException | SQLException | NuevaExcepcionChecada e){
            System.out.println("Hubo un problema con la información proporcionada");
        }
        // Los tipos de excepciones no deben estar en la linea descente/ascente
        catch ( IndexOutOfBoundsException | NuevaExcepcionRuntime e){
            System.out.println("Hubo un error");
        }
        catch (RuntimeException e){
            System.out.println("Algo malio sal");
        }
    }
}
