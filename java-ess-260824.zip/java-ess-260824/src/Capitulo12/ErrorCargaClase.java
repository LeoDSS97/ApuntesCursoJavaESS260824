package Capitulo12;

public class ErrorCargaClase {

    //Iniciador estatico
    static {
        System.out.println(("Error interno antes de cargar en memoria"));
        int error = 1/(1-1);
    }
    //Iniciador normal
    {
        System.out.println("Estamos con la clase ErrorCargaClase ya cargada en " +
                "memoria");
    }

    public ErrorCargaClase() {
        System.out.println("Estamos creando un objeto ErrorCargaClase");
    }
}
