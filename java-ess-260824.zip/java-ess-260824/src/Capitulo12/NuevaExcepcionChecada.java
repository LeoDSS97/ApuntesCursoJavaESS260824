package Capitulo12;

public class NuevaExcepcionChecada extends Exception{


    public NuevaExcepcionChecada() {
        super("El programador cometio un error");
    }
}
