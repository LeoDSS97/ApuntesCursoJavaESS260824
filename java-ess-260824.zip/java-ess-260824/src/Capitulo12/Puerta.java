package Capitulo12;

public class Puerta implements AutoCloseable{
    static int idPuertas = 0;

    String numeroPuerta;

    public Puerta() {
        idPuertas++;
        numeroPuerta = ""+idPuertas;
        System.out.println("Se ha creado la puerta #" + numeroPuerta);
    }

    @Override
    public void close() throws Exception {
        System.out.println("Se ha cerrado la puerta #" + numeroPuerta);
    }
}
