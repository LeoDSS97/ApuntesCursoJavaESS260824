package Capitulo05;

import java.util.ArrayList;

public class Inicio {
    public static void main(String[] args) {
        //ejemplosArreglos();
        //ejemploArrayList();
        ejemplosCiclosWhile();
    }


    public static void ejemplosArreglos(){
        //Declarar arreglos
        int [] numeros;
        //Declarar un arreglo Bidimensional
        int [] otrosNumeros[], otroArreglo;

        //Declarar e inicializar el arreglo
        // arreglo anonimo
        int [] numerosAsignados = {1,2,3,4,5};

        //Inicializar los arreglos
        numeros = new int[10];
        //Cambiamos un valor
        numeros[5] = 100;
        System.out.println("Tamaño numeros = " + numeros.length);
        System.out.println("Numero en la primer posicion " + numeros[0]);
        System.out.println("Numero en la segunda posicion " + numeros[1]);
        System.out.println("Numero en la tercera posicion " + numeros[2]);
        System.out.println("Numero en la cuarta posicion " + numeros[3]);
        System.out.println("Numero en la quinta posicion " + numeros[4]);
        System.out.println("Numero en la sexta posicion " + numeros[5]);
        System.out.println("Numero en la septima posicion " + numeros[6]);
        System.out.println("Numero en la octava posicion " + numeros[7]);
        System.out.println("Numero en la novena posicion " + numeros[8]);
        System.out.println("Numero en la decima posicion " + numeros[9]);

        otroArreglo = new int[] {1,2,3,4,5,6,7,8};

        //Manualmente indicamos fila por fila la cantidad de columnas a tener cada una de ellas
        otrosNumeros = new int[5][];
        otrosNumeros[0] = new int[5];
        otrosNumeros[1] = new int[4];
        otrosNumeros[2] = new int[3];
        otrosNumeros[3] = new int[2];
        otrosNumeros[4] = new int[1];
        //De forma generica indicamos la misma cantidad de columnas para cada fila
        otrosNumeros = new int[5][5];
        otrosNumeros[3][3] = 999;
        System.out.println("Otros numeros" + otrosNumeros[3] +"\n" + otrosNumeros[3][3] );

        //Ciclo for each
        for(int [] fila : otrosNumeros){
            System.out.println("Fila");
            for (int columna : fila){
                System.out.print("columna = " + columna + "   -   ");
            }
            System.out.println();
        }
        
        //ciclo for tradicional tiene 3 componentes opcionales
        //for (/*declaracion variable*/;/*control*/; /*actualizacion*/)
        //{
            //Funcionalmente esto es un loop infinito
        //}
        int i = 0;
        for (;i<10;)
        {
            System.out.println("i = " + i);
            i+=1;
        }
        //Todavia podria utilizar a la variable i
        i = 10;
        for (int j = 0; j < 10; j++){
            System.out.println("j = " + j);
        }
        // Aquí j ya no existe y no la puedo mandar llamar.
        //j = 10;
    }

    public static void ejemploArrayList(){
        //ArrayList genera arreglos de Objetos internamente para
        //que nosotros solos los reutilicemos como si fuese uno solo
        //Los genericos < > son una forma de darle más versatilidad al código
        //Representan distintos tipos de objetos, pero que se reemplazan a tiempo
        //de compilación con casteo de Object
        ArrayList <String> mensajes = new ArrayList<>();
        mensajes.add("a");
        mensajes.add("b");
        mensajes.add("c");
        mensajes.add("d");
        mensajes.add("e");

        for(String mensaje : mensajes){
            System.out.println("mensaje = " + mensaje);
        }
        System.out.println("************************************\n\n\n");
        mensajes.remove("d");
        mensajes.remove(1);
        //ace
        for(String mensaje : mensajes){
            System.out.println("mensaje = " + mensaje);
        }
        System.out.println("************************************\n\n\n");
        mensajes.add(1, "1");
        mensajes.add(mensajes.size()-1, "f");
        //a1cef
        for(String mensaje : mensajes){
            System.out.println("mensaje = " + mensaje);
        }
        System.out.println("************************************\n\n\n");

        //Esto no copia ni resguarda la informacion
        //var malbackcup = mensajes;
        // nos ayuda a replicar el objeto
        var backup = mensajes.clone();

        var otroBackup = new ArrayList<String>(mensajes);

        for(String mensaje : (ArrayList<String>)backup){
            System.out.println("mensaje desde backup = " + mensaje);
        }

        // Quedó vacío el ArrayList
        mensajes.clear();



        /*for(String mensaje : malbackcup){
            System.out.println("mensaje desde backup ya vaciando a mensajes = " + mensaje);
        }*/

    }


    public static void ejemplosCiclosWhile(){

        int inicio = 0;

        System.out.println("Previos a entrar en while");
        //While puede o no ejecutarse
        while(inicio > 0 & inicio < 10)
        {
            System.out.println("Contando del 1 al 10" + inicio++);
        }

        System.out.println("Previos a entrar en do while");
        //Do while siempre se ejecuta al menos una sola vez
        do
        {
            System.out.println("Contando del 1 al 10: " + inicio++);
            if(inicio == 5){
                break;
            }
        }while(inicio > 0 & inicio < 10);

        //Labels etiquetas se utilizan en conjunto con lo que es el
        // continue o el break para cambiar su comportamiento
        EXTERNO:for (int filas = 0;/*declaracion*/
            filas < 5;/*condicion*/
            filas++/*actualizacion*/){
            System.out.println("Fila %d#".formatted(filas));
                INTERNO:for (int columnas = 0; columnas < 5; columnas++)
                {
                    //char c = 'a';
                    if (columnas==3)
                    {
                        //Continue originalmente imprimia 0,1,2,4
                        //Emulamos el comportamiento del break, pero sin ejecutar el
                        //cuerpo completo del ciclo externo
                        //continue EXTERNO;
                        //Break originalmente imprimia 0,1,2
                        //Podemos terminar por completo un ciclo externo en su totalidad
                        break EXTERNO;
                    }
                    System.out.print("Columna %s   ".formatted(columnas));
                }
            System.out.println("");
        }
        System.out.println("Resto del cuerpo del método");

    }

}
