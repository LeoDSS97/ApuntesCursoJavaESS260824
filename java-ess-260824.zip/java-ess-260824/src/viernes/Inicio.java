package viernes;

import java.util.ArrayList;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;

public class Inicio {

    public static void main(String[] args) {
        //ejemploTradicional();
        //ejemploRecord();
        //ejemploStreams();
        ejemploOptional();

    }

    public static void ejemploTradicional(){
        System.out.println("Estamos por crear a la primer persona tradicional");
        PersonaTradicional tradicional = new PersonaTradicional(
                "Leonardo",
                "Sanchez",
                "Sereno",
                "CURP",
                "leonardo.sanchez@netec.com.mx",
                60
        );
        System.out.println("Estamos por crear a la segunda persona tradicional");
        tradicional = new PersonaTradicional();
        System.out.println("Estamos por crear a la tercera persona tradicional");
        tradicional = new PersonaTradicional(null,null,null,null,null,0);
    }

    public static void ejemploRecord(){
        System.out.println("Estamos por crear a la primer persona DTO");
        PersonaDTO dto = new PersonaDTO(
                "Leonardo",
                "Sanchez",
                "Sereno",
                "CURP",
                "leonardo.sanchez@netec.com.mx",
                60
        );
        System.out.println("Estamos por crear a la segunda persona DTO");
        dto = new PersonaDTO();
        System.out.println("Estamos por crear a la tercera persona DTO");
        dto = new PersonaDTO(null,null,null,null,null,0);
        dto.apellido_materno();

    }

    public static void ejemploClasesAnonimas(){
        //En java las interfaces y las clases abstractas no pueden tener objetos
        //por ellas solas
        ClaseAbstracta prueba = new ClaseAbstracta() {
        //Clase anonima que extiende a clase Abstracta
            @Override
            //Que queremos estar haciendo
            public String funcion(String entrada) {
                 //como lo quiero hacer
                return "";
            }
        };

                                    /*Como lo quiero hacer*/
        Interfaz_Funcional funcion = entrada -> { return entrada.toUpperCase();};
        funcion = entrada -> "";
        funcion = entrada -> {return "";};
        InterfazFuncionalDosEntradas otra_funcion = (entrada, otra_entrada) -> {return"";};
        otra_funcion = (String entrada, String otra_entrada) -> {return "";};
        otra_funcion = (var entrada, var otra_entrada) -> {return "";};
        /* Estructura de una lambda es el equivalente a la firma de un metodo pero
        * con la estrutura cambiada de lugar
        * modificador acceso tipo retorno nombre (lista parametros)
        * retorno (entradas)
        *
        * En lambda como se usan interfaces funcionales solo hay metodo
        * Sintaxis basica / canonica de una lambda
        * (entradas) -> {el cuerpo de mi metodo;}
        * entrada -> {el cuerpo del metodo;}
        * (entrada, otra entrada) -> {el cuerpo del metodo;}
        * (Tipo entrada, Tipo otra entrada) -> {el cuerpo del metodo;}
        * (var entrada, var otra entrada) -> {el cuerpo del metodo;}
        * entrada -> "retorno";
        * entrada -> {return "retorno";}
        *
        * */
        funcion = entrada -> { return entrada.toUpperCase();};
        funcion = String::toUpperCase;
        Interfaz_Funcional_Numerica funcion_numerica = entrada -> {return String.valueOf(entrada);};
        funcion_numerica = String::valueOf;
        Interfaz_FuncionalProveedora funcion_provedora = () -> new StringBuilder();
        funcion_provedora = StringBuilder::new;


        /*Referencias a metodos son una forma de simplificar todavia mas lo que son las
        * lambda, mediante omitir gran parte del cuerpo y especificar de que metodo estamos hablando
        *
        * String entrada -> { return entrada.toUpperCase();}
        * Forma ligada a un objeto
        * Mi objeto en cuestion es entrada mandarle llamar al metodo toUpperCase();
        * String :: metodoEnCuestion
        *
        * Integer entrada -> { return Clase.metodoEstatico(entrada);};
        * Forma ligada a la clase
        * Mi objeto se pasa como atributo a un metodo Estatico y que yo especifico cual
        * metodo estatico de que clase es que voy a llamar para hacer esta converison
        * CLASE :: metodoEnCuestion
        *
        * No entrada () -> return es un nuevo objeto new Object ();
        * Forma ligada a la construccion de objetos
        * Como no hay entradas y el retorno es un nuevo objeto de una cierta clase
        * LACLASE :: new
        *
        * */


    }

    public static void ejemploLambdas(){
        Function<String, Integer> funcion = (String entrada) -> {return Integer.valueOf(entrada);};
        //Algunas interfaces funcionales tienen metodos auxiliares (default)
        //Referencia de metodo
        //Function<String, Integer> funcion = Integer::valueOf;
        Predicate<Integer> predicado = (entrada) -> {return entrada > 18;};
        //Los parentesis son "obligatorios" solamente si se declarada la lambda
        //fuera de un metodo
        Supplier<StringBuilder> proveedor = () -> new StringBuilder();
        //Referencia a metodo con el operador new
        //Supplier<StringBuilder> proveedor = StringBuilder::new;
        Consumer<String> consumidor = entrada -> System.out.println(entrada);
        //Referencia a metodo con un objeto de por medio
        //consumidor = System.out::println;
        //UnaryOperator<String> otraFuncion = entrada -> entrada.toUpperCase();
        UnaryOperator<String> otraFuncion = String::toUpperCase;}

    public static void ejemploStreams(){
        //Los Streams de Java

        //Los que tienen que ver con la I/O de informacion
        //Estos no los cubrimos en este curso

        //Los que tienen que ver con la evaluacion diferida.
        //Especificamos el codigo ahora, pero lo hacemos eventualemte

        //Forma Tradicional con las colecciones de Java

        ArrayList<PersonaDTO> personas = new ArrayList<>();
        for(int i = 0; i < 10; i++)
        {
            personas.add(new PersonaDTO());
        }
//        for(PersonaDTO dto : personas){
//            System.out.println("dto = " + dto);
//        }

        //Conversion de una coleccion normal de Java
        //A trabajarlo como un stream datos
        //Pensemos en ellos como compuertas que esperan un flujo agua.
        Stream<PersonaDTO> stream_personas = personas.stream();
        //Escenario_1 Ya tenemos a la coleccion de las personas que vamos a estar utilizando
        //Operaciones Iniciales
        Consumer<PersonaDTO> interfaz_funcional = (dto -> System.out.println(dto));
        //Operaciones Intermedias
        //stream_personas
        //        .peek(interfaz_funcional.andThen(entrada -> System.out.println("Se ha impreso los datos de la persona: " + entrada.nombre())))
                //Operaciones Finales
        //        .forEach(entrada -> System.out.println("Ha salido del un dato del stream"));
        //stream_personas.forEach(entrada -> System.out.println("Ha salido del un dato del stream"));
        //System.out.println("stream_personas = " + stream_personas);

        Predicate<PersonaTradicional> rango_edades = persona -> (persona.getEdad()> 18);

        Stream<PersonaTradicional> personas_modificables =
            Stream
                    .generate(() -> {return new PersonaTradicional("Nombre"+((int) (Math.random() * 1000)),
                    "ApellidoP: "+((int) (Math.random()*1000)),
                    "ApellidoM: "+((int) (Math.random()*1000)),
                    "Identificacion: "+((int) (Math.random()*1000)),
                    "usuario"+((int) (Math.random()*1000))+"@correo.com",
                    ((int) (Math.random()*100)));})
                    .filter(rango_edades.and(persona ->  persona.getEdad() < 80))
                    .limit(15)
                    .peek(System.out::println);
        Stream <String> nombres_personas = personas_modificables
                    .map(PersonaTradicional::getNombre);

        nombres_personas.forEach(nombre -> System.out.println(nombre.toUpperCase()));
        //Stream infinito de personas con valores predeterminados y
        //Referencia a metodo constructor preterminado
        //Stream.generate(PersonaTradicional::new);


        System.out.println(PersonaTradicional.numeroPersonas);
    }

    public static void ejemploOptional(){

        Stream<PersonaTradicional> personas =
                Stream.generate(PersonaTradicional::new)
                                .peek(System.out::println)
                                .skip(10)
                                .limit(10);
        var resultado = personas.findFirst();

        System.out.println("Haciendo pruebas con el contenido opcional");
        System.out.println("Hay contenido?");
        System.out.println("resultado.isEmpty() = " + resultado.isEmpty());
        System.out.println("resultado.isPresent() = " + resultado.isPresent());
        System.out.println("Hay contenido? -> Responder Valor predeterminado / Error");
        System.out.println("resultado.orElse() = " +
                resultado.orElse( new PersonaTradicional()));
        System.out.println("resultado.orElseThrow() = " +
                resultado.orElseThrow());
        System.out.println("resultado.orElseThrow() = " +
                resultado.orElseThrow(IllegalArgumentException::new));
        Runnable resultadoOpcional = () -> {
            System.out.println("No hay valores para este dato y por lo tanto ahi viene una excepcion");
            throw new RuntimeException("Valores vacios en el opcional");
        };
        resultado.ifPresentOrElse(System.out::println, resultadoOpcional);

        // Optional <PersonaTradicional> resultado




    }

}
