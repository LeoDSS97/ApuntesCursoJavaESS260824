package viernes;
//Version 17 de Java oficiales
//Dado que extienden la clase abstracta llamada Record no permiten al menos
//la herencia de otras clases y como implicitamente se marcan como finales,
//tampoco permiten ser extendidas por otras clases.
import java.io.Serializable;
import java.util.Objects;
public record PersonaDTO(String nombre, String apellido_paterno,
                         String apellido_materno, String identificacion,
                         String correo, int edad) implements Serializable {
    /* Esto no puede funcionar extends PersonaTradicional{*/
    public PersonaDTO {
        //Para este punto ya tendriamos los atributos
        // this.atributo = atributo
        // Esto al considerarse redundante no nos permite ponerlo de forma explicita
        Objects.requireNonNull(nombre, "El nombre no puede estar vacio");
        Objects.requireNonNull(apellido_paterno, "El apellido paterno no puede estar vacio");
        Objects.requireNonNull(apellido_materno, "El apellido materno no puede estar vacio");
        Objects.requireNonNull(identificacion, "Falta la identificación");
        Objects.requireNonNull(correo, "El nombre no puede estar en blanco");

        if (edad <18 || edad > 80){
            throw new IllegalArgumentException("La edad es invalida para poderte registrar");
        }

        nombre = nombre.toUpperCase();
        apellido_paterno = apellido_paterno.toUpperCase();
        apellido_materno = apellido_materno.toUpperCase();
        //Como hayan quedado mis atributos se volvera hacer un this.atributo = resultado de ese atributo
        //this atributo = atributo.resultante
    }

    //Este tipo constructor se denomina el constructor canonico
    /*    public PersonaDTO(String nombre, String apellido_paterno, String apellido_materno, String identificacion, String correo, int edad) {
        this.nombre = nombre;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.identificacion = identificacion;
        this.correo = correo;
        this.edad = edad;
    }*/

    static int numeroPersona = 0;

    //Constructor customizado
    public PersonaDTO() {
        //Encadenado al constructor canonico
        this("Nombre"+numeroPersona,
                "ApellidoP",
                "ApellidoM",
                "CURP",
                "usuario@correo.com",
                (++numeroPersona+60));
    }
    //Aquí el constructor predeterminado difícilmente va a existir
    //public PersonaDTO(){};
    //public PersonaDTO(nombre, apellidos, identification, correo, edad){}

    //El record no puede tener mas atributos de instancias fuera de los listados al inicio
    //String atributo = "Hola mundo";
    //Puedo tener campos ligados a la clase y no hay problemas
    static String atributo = "Hola mundo";

    //Al igual que las clases normales podemos hacer uso de las metodos de instancia
    //o de metodos de clase
    public void validar(){

    }
    public static void otraValidacion(){

    }
    //Al igual que las clases convencionales, no podemos tener los metodos abstractos
    //public abstract void metodoAbstracto();

}
