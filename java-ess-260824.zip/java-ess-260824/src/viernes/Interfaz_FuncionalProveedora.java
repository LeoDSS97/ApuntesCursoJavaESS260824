package viernes;

public interface Interfaz_FuncionalProveedora {
    public abstract Object proveer();
}
