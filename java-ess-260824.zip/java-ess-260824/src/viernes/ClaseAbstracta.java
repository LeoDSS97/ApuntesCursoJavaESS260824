package viernes;

public abstract class ClaseAbstracta {
    public abstract String funcion(String entrada);
}
