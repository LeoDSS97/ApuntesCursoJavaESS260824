package viernes;

@FunctionalInterface
public interface Interfaz_Funcional {

    //SAM Single Abstract Method
    //Los metodos de Object estan excluidos de esta regla
    //Que quiero hacer
    public abstract String funcion(String entrada);

    //Todos estos metodo que vienen de Object no entran en la regla de la
    //Cantidad de los metodos abstractos
    public abstract String toString();
    public abstract int hashCode();
    public abstract boolean equals(Object obj);





}
