package viernes;

public interface InterfazFuncionalDosEntradas {
    public abstract String funcion(String entrada, String segunda_entrada);
}
