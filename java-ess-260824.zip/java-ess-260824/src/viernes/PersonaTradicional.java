package viernes;

import java.util.Objects;
//Java Bean DTO  ...
//Contienen varios atributos para ser almacenados (En una Base de datos / Archivo)
public class PersonaTradicional {
    public static int numeroPersonas = 0;
    private String nombre;
    private String apellido_paterno;
    private String apellido_materno;
    private String identificacion;
    private String correo;
    private int edad;
    //......
    public PersonaTradicional(){
        this("Nombre"+((int) (Math.random() * 1000)),
                "ApellidoP",
                "ApellidoM",
                "CURP"+((int) (Math.random() * 1000)),
                "usuario@correo.com",
                0+((int) (Math.random() * 100)));
        numeroPersonas++;
    }

    public PersonaTradicional(String nombre, String apellido_paterno, String apellido_materno, String identificacion, String correo, int edad) {
        this.nombre = nombre;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.identificacion = identificacion;
        this.correo = correo;
        this.edad = edad;

        Objects.requireNonNull(nombre, "El nombre no puede estar vacio");
        Objects.requireNonNull(apellido_paterno, "El apellido paterno no puede estar vacio");
        Objects.requireNonNull(apellido_materno, "El apellido materno no puede estar vacio");
        Objects.requireNonNull(identificacion, "Falta la identificación");
        Objects.requireNonNull(correo, "El nombre no puede estar en blanco");

        if (edad < 0 || edad > 100){
            throw new IllegalArgumentException("La edad es invalida para poderte registrar");
        }
        numeroPersonas++;

    }

    public String getNombre(){
        return this.nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public String getApellido_paterno (){
        return apellido_paterno;
    }
    public String getApellido_materno(){
        return apellido_materno;
    }
    public String getIdentificacion(){
        return identificacion;
    }
    public String getCorreo(){
        return correo;
    }
    public int getEdad(){
        return edad;
    }
    public void setApellido_paterno(String apellido_paterno) {
        this.apellido_paterno = apellido_paterno;
    }
    public void setApellido_materno(String apellido_materno) {
        this.apellido_materno = apellido_materno;
    }
    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "PersonaTradicional{" +
                "nombre='" + nombre + '\'' +
                ", apellido_paterno='" + apellido_paterno + '\'' +
                ", apellido_materno='" + apellido_materno + '\'' +
                ", identificacion='" + identificacion + '\'' +
                ", correo='" + correo + '\'' +
                ", edad=" + edad +
                '}';
    }
}
