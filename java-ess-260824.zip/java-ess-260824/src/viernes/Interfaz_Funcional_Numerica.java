package viernes;

public interface Interfaz_Funcional_Numerica {
    public abstract String funcion(Integer entrada);
}
